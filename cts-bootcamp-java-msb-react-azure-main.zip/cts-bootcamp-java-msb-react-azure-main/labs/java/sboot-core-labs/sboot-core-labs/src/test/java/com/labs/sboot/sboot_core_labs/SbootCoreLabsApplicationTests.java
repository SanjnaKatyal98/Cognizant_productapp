package com.labs.sboot.sboot_core_labs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbootCoreLabsApplicationTests {

	@Test
	void contextLoads() {
	}

}
