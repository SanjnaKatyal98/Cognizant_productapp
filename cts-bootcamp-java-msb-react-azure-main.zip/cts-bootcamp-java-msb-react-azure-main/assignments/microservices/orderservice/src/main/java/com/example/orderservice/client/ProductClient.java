package com.example.orderservice.client;

import com.example.orderservice.model.Product;
import com.example.orderservice.model.ProductDto;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "product-service")
public interface ProductClient {
    @GetMapping("/products/{id}")
    @CircuitBreaker(name = "productService", fallbackMethod = "getProductFallback")  // Circuit breaker applied
    ProductDto getProductById(@PathVariable("id") Long id);

    default ProductDto getProductFallback(Long id, Throwable throwable) {
        // Fallback method when circuit is open or call fails
        return new ProductDto(id, "Fallback Product", "Fallback Description", 0.0, false);
    }




}
