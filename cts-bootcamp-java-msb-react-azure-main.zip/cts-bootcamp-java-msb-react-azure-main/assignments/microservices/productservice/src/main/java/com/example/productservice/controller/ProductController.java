package com.example.productservice.controller;

import com.example.productservice.kafka.KafkaProducerService;
import com.example.productservice.model.Product;
import com.example.productservice.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

import java.util.Map;

@RestController
@RequestMapping("/products")
public class ProductController {
    private static final Map<Integer, Product> productRepo = new HashMap<>();
    @Autowired
    private KafkaProducerService kafkaProducerService;
    @Autowired
    private ProductService productService;



    static {
        productRepo.put(1, new Product(1, "Laptop", 1500.0));
        productRepo.put(2, new Product(2, "Mobile", 800.0));
    }

    @GetMapping("/{id}")
    public Product getProductById(@PathVariable("id") int id) {
        return productRepo.get(id);
    }

    @GetMapping
    public Map<Integer, Product> getAllProducts() {
        return productRepo;
    }

    @PostMapping
    public Product addProduct(@RequestBody Product product) {
        productRepo.put(product.getId(), product);
        return product;
    }
    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        Product newProduct = productService.createProduct(product);
        kafkaProducerService.sendMessage("Product created: " + newProduct.getName());
        return ResponseEntity.ok(newProduct);
    }


}
