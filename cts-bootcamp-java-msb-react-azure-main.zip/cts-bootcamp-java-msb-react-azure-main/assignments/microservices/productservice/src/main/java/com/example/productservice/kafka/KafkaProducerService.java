package com.example.productservice.kafka;

import org.springframework.stereotype.Service ;

@Service

public class KafkaProducerService {
    private static final String TOPIC = "product-events";

    private final KafkaTemplate <String, String> kafkaTemplate;

    public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(String message) {
        kafkaTemplate.send(TOPIC, message);
    }

}
