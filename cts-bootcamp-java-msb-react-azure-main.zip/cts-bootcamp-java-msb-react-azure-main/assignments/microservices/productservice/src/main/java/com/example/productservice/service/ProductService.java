package com.example.productservice.service;

import com.example.productservice.model.Product;

public class ProductService {
    public Product createProduct(Product product) {

        return product;
    }
}
