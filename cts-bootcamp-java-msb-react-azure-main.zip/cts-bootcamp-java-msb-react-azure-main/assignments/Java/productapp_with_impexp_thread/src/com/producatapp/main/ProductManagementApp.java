package com.producatapp.main;

import java.util.List;
import java.util.Scanner;

import com.productapp.exception.ProductNotFoundException;
import com.productapp.impexp.ExportTask;
import com.productapp.impexp.ImportTask;
import com.productapp.model.Product;
import com.productapp.model.ProductCategory;
import com.productapp.service.ProductService;

public class ProductManagementApp {
	private static ProductService productService = new ProductService();

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		while (true) {
			System.out.println(
					"1] Add Product\n2] Update Product\n3] Delete Product\n4] View Product\n5] View All Products\n6] Print Statistics\n7] Import [Product Details]\n8] Export [Product Details]\n9] Exit");
			int choice = scanner.nextInt();
			scanner.nextLine(); 

			switch (choice) {
			case 1:
				System.out.print("Enter Product ID: ");
				int id = scanner.nextInt();
				System.out.print("Enter Product Category (MOBILES, LAPTOPS, FURNITURES, STATIONARY): ");
				ProductCategory category = ProductCategory.valueOf(scanner.nextLine().toUpperCase());
				System.out.print("Enter Product Description: ");
				String description = scanner.nextLine();
				System.out.print("Enter Product Price: ");
				double price = scanner.nextDouble();
				System.out.print("Is the product active? (true/false): ");
				boolean active = scanner.nextBoolean();
				productService.addProduct(new Product(id, category, description, price));
				System.out.println("Product added.");
				break;
			case 2:
				try {
					System.out.print("Enter Product ID to update: ");
					int updateId = scanner.nextInt();
					System.out.print("Enter new Product Category (MOBILES, LAPTOPS, FURNITURES, STATIONARY): ");
					ProductCategory newCategory = ProductCategory.valueOf(scanner.next().toUpperCase());
					System.out.print("Enter new Product Description: ");
					String newDescription = scanner.next();
					System.out.print("Enter new Product Price: ");
					double newPrice = scanner.nextDouble();
					System.out.print("Is the product active? (true/false): ");
					boolean newActive = scanner.nextBoolean();
					productService.updateProduct(updateId,
							new Product(updateId, newCategory, newDescription, newPrice));
					System.out.println("Product updated.");
				} catch (ProductNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 3:
				try {
					System.out.print("Enter Product ID to delete: ");
					int deleteId = scanner.nextInt();
					productService.deleteProduct(deleteId);
					System.out.println("Product deleted.");
				} catch (ProductNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				System.out.print("Enter Product ID to view: ");
				int viewId = scanner.nextInt();
				Product product = productService.viewProduct(viewId);
				if (product != null) {
					System.out.println("Product Details: " + product);
				} else {
					System.out.println("Product not found.");
				}
				break;
			case 5:
				List<Product> allProducts = productService.viewAllProducts();
				System.out.println("All Products:");
				allProducts.forEach(System.out::println);
				break;
			case 6:
				System.out.print("Enter name to filter statistics: ");
				String nameFilter = scanner.nextLine();
				productService.printStatistics(nameFilter);
				break;
			case 7:
				System.out.print("Enter file path for import (e.g., products.txt): ");
				String importPath = scanner.nextLine();
				new Thread(new ImportTask(productService, importPath)).start();
				break;
			case 8:
				System.out.print("Enter file path for export (e.g., products.txt): ");
				String exportPath = scanner.nextLine();
				new Thread(new ExportTask(productService, exportPath)).start();
				break;
			case 9:
				System.out.println("Exiting...");
				scanner.close();
				return;
			default:
				System.out.println("Invalid choice. Please try again.");
			}
		}
	}

}
