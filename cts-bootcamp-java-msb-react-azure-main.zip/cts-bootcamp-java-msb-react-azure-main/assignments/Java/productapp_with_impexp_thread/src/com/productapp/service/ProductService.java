package com.productapp.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.productapp.exception.ProductNotFoundException;
import com.productapp.model.Product;
import com.productapp.model.ProductCategory;

public class ProductService {
	private List<Product> products = Collections.synchronizedList(new ArrayList<>());
	 
    public void addProduct(Product product) {
        products.add(product);
    }
 
    public void updateProduct(int id, Product updatedProduct) throws ProductNotFoundException {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getId() == id) {
                products.set(i, updatedProduct);
                return;
            }
        }
        throw new ProductNotFoundException("Product with ID " + id + " not found.");
    }
 
    public void deleteProduct(int id) throws ProductNotFoundException {
        boolean removed = products.removeIf(product -> product.getId() == id);
        if (!removed) {
            throw new ProductNotFoundException("Product with ID " + id + " not found.");
        }
    }
 
    public Product viewProduct(int id) {
        return products.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }
 
    public List<Product> viewAllProducts() {
        return new ArrayList<>(products);
    }
 
    public void printStatistics(String nameFilter) {
        long countAbove10k = products.stream().filter(p -> p.getPrice() > 10000).count();
        System.out.println("Number of products above 10k: " + countAbove10k);
 
        Map<ProductCategory, Long> categoryCount = products.stream()
                .collect(Collectors.groupingBy(Product::getCategory, Collectors.counting()));
        System.out.println("Number of products by category: " + categoryCount);
 
        Map<ProductCategory, Double> avgPriceByCategory = products.stream()
                .collect(Collectors.groupingBy(Product::getCategory, Collectors.averagingDouble(Product::getPrice)));
        System.out.println("Average price by category: " + avgPriceByCategory);
 
        List<Integer> productIdsWithName = products.stream()
                .filter(p -> p.getDescription().toLowerCase().contains(nameFilter.toLowerCase()))
                .map(Product::getId)
                .collect(Collectors.toList());
        System.out.println("Product IDs containing '" + nameFilter + "': " + productIdsWithName);
    }
 
    public void importProducts(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 7) {
                    int id = Integer.parseInt(data[0]);
                    ProductCategory category = ProductCategory.valueOf(data[1].toUpperCase());
                    String description = data[2];
                    double price = Double.parseDouble(data[3]);
                    boolean active = Boolean.parseBoolean(data[4]);
                    LocalDateTime createTime = LocalDateTime.parse(data[5]);
                    LocalDateTime updateTime = LocalDateTime.parse(data[6]);
                    Product product = new Product(id, category, description, price);
                    addProduct(product);
                }
            }
            System.out.println("Import completed.");
        } catch (IOException e) {
            System.err.println("Error importing products: " + e.getMessage());
        }
    }
 
    public void exportProducts(String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Product product : products) {
                writer.write(product.toString());
                writer.newLine();
            }
            System.out.println("Export completed.");
        } catch (IOException e) {
            System.err.println("Error exporting products: " + e.getMessage());
        }
    }

}
