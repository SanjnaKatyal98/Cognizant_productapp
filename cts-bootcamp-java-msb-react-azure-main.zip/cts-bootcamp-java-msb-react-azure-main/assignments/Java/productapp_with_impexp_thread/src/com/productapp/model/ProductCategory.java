package com.productapp.model;

public enum ProductCategory {
	MOBILES , LAPTOPS, Furnitures, Stationary

}
