package com.productapp.model;

import java.time.LocalDateTime;
// pojo class
public class Product {
	public int id;
	public ProductCategory category;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public ProductCategory getCategory() {
		return category;
	}
	public void setCategory(ProductCategory category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public LocalDateTime getCreateTime() {
		return createTime;
	}
	public void setCreateTime(LocalDateTime createTime) {
		this.createTime = createTime;
	}
	public LocalDateTime getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(LocalDateTime updateTime) {
		this.updateTime = updateTime;
	}
	public String description;
	public double price;
	public boolean active;
	public LocalDateTime createTime;
	public LocalDateTime updateTime;
	@Override
	public String toString() {
		return "Product [id=" + id + ", category=" + category + ", description=" + description + ", price=" + price
				+ ", active=" + active + ", createTime=" + createTime + ", updateTime=" + updateTime + "]";
	}
	public Product(int id, ProductCategory category, String description, double price) {
		super();
		this.id = id;
		this.category = category;
		this.description = description;
		this.price = price;
		this.active = active;
		this.createTime = createTime;
		this.updateTime = updateTime;
	}

	

}
