package com.productapp.impexp;

import com.productapp.service.ProductService;

public class ExportTask implements Runnable {
	private final ProductService productService;
	private final String filePath;

	public ExportTask(ProductService productService, String filePath) {
		this.productService = productService;
		this.filePath = filePath;
	}

	@Override
	public void run() {
		productService.exportProducts(filePath);
	}

}
