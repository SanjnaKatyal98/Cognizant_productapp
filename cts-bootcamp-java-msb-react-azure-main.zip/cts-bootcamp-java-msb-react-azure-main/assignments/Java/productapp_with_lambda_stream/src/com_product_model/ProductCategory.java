package com_product_model;

public enum ProductCategory {
	MOBILES , LAPTOPS, Furnitures, Stationary


}
