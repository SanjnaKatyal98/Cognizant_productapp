package com_product_model;

import java.time.LocalDateTime;


public class Product {
	public int id;
	public ProductCategory category;
	public String description;
	public double price;
	public boolean active;
	public LocalDateTime createTime;
	public LocalDateTime updateTime;
	@Override
	public String toString() {
		return "Product [id=" + id + ", category=" + category + ", description=" + description + ", price=" + price
				+ ", active=" + active + ", createTime=" + createTime + ", updateTime=" + updateTime + "]";
	}
	public Product(int id, ProductCategory category, String description, double price) {
		super();
		this.id = id;
		this.category = category;
		this.description = description;
		this.price = price;
		this.active = active;
		this.createTime = createTime;
		this.updateTime = updateTime;
	}


}
