package com_productapp_main;

import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com_producat_exception.ProductNotFoundException;
import com_producat_service.ProductService;
import com_product_model.Product;
import com_product_model.ProductCategory;

public class ProductManagementApp {
	private static final ProductService productService = new ProductService();
	 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
 
        while (running) {
            System.out.println("\nProduct Management Menu:");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. View Product");
            System.out.println("5. View All Products");
            System.out.println("6. Print Statistics");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
 
            int choice = scanner.nextInt();
            scanner.nextLine(); 
 
            switch (choice) {
                case 1:
                    addProduct(scanner);
                    break;
                case 2:
                    updateProduct(scanner);
                    break;
                case 3:
                    deleteProduct(scanner);
                    break;
                case 4:
                    viewProduct(scanner);
                    break;
                case 5:
                    viewAllProducts();
                    break;
                case 6:
                    printStatistics();
                    break;
                case 7:
                    running = false;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }
 
    private static void addProduct(Scanner scanner) {
        try {
            System.out.print("Enter product category (MOBILES, LAPTOPS, FURNITURES, STATIONARY): ");
            ProductCategory category = ProductCategory.valueOf(scanner.nextLine().toUpperCase());
            System.out.print("Enter product description: ");
            String description = scanner.nextLine();
            System.out.print("Enter product price: ");
            double price = scanner.nextDouble();
            scanner.nextLine(); 
 
            Product product = productService.addProduct(category, description, price);
            System.out.println("Product added: " + product);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: Invalid product category. Please try again.");
        }
    }
 
    private static void updateProduct(Scanner scanner) {
        System.out.print("Enter product ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 
 
        try {
            System.out.print("Enter new description: ");
            String description = scanner.nextLine();
            System.out.print("Enter new price: ");
            double price = scanner.nextDouble();
            scanner.nextLine(); 
 
            productService.updateProduct(id, description, price);
            System.out.println("Product updated.");
        } catch (ProductNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
 
    private static void deleteProduct(Scanner scanner) {
        System.out.print("Enter product ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 
 
        productService.deleteProduct(id);
        System.out.println("Product deleted.");
    }
 
    private static void viewProduct(Scanner scanner) {
        System.out.print("Enter product ID to view: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 
 
        try {
            Product product = productService.viewProduct(id);
            System.out.println(product);
        } catch (ProductNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
 
    private static void viewAllProducts() {
        List<Product> products = productService.viewAllProduct();
        if (products.isEmpty()) {
            System.out.println("No products available.");
        } else {
            for (Product product : products) {
                System.out.println(product);
            }
        }
    }
 
    private static void printStatistics() {
        System.out.println("Statistics:");
 
        int countAbove10k = productService.countProductsAbovePrice(10000);
        System.out.println("Number of products priced above 10k: " + countAbove10k);
 
        Map<Object, IntSummaryStatistics> categoryCountMap = productService.countProductsByCategory();
        System.out.println("Number of products by category:");
        categoryCountMap.forEach((category, count) -> 
            System.out.println(category + ": " + count)
        );
 
        Map<ProductCategory, Double> averagePriceMap = productService.averagePriceByCategory();
        System.out.println("Average price by category:");
        averagePriceMap.forEach((category, avgPrice) -> 
            System.out.println(category + ": " + avgPrice)
        );
    }
	

}
