package com_producat_exception;

public class ProductNotFoundException  extends Exception{

	public ProductNotFoundException(String message) {
		super(message);
	}


}
