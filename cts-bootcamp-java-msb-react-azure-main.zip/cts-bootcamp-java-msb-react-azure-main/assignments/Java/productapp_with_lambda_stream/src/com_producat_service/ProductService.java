package com_producat_service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com_producat_exception.ProductNotFoundException;
import com_product_model.Product;
import com_product_model.ProductCategory;



public class ProductService {
	private final Map<Integer, Product> productMap = new HashMap<>();
	private int currentId = 1;

	// Add the product
	public Product addProduct(ProductCategory category, String description, double price) {
		Product product = new Product(currentId++, category, description, price);
		productMap.put(product.id, product);
		return product;
	}

	// Update the product
	public void updateProduct(int id, String description, double price) throws ProductNotFoundException {
		Product product = productMap.get(id);
		if (product == null) {
			throw new ProductNotFoundException("Product not found");
		}
		product.description = description;
		product.price = price;
		product.updateTime = LocalDateTime.now();

	}

	// Delete the product
	public void deleteProduct(int id) {
		productMap.remove(id);
	}
	//view Product by id
	public Product viewProduct(int id) throws ProductNotFoundException {
		Product product = productMap.get(id);
		if(product==null) {
			throw new ProductNotFoundException("Prodct not found");
		}
		return product;
	}
	//view All Product
	public List<Product> viewAllProduct(){
		return new ArrayList<>(productMap.values());
	}
	public int countProductsAbovePrice(double threshold) {
		return (int) productMap.values().stream()
				.filter(product -> product.price > threshold)//using lambda and stream
				.count();
	
	}
	public Map<Object, IntSummaryStatistics> countProductsByCategory() {
		return productMap.values().stream()
				.collect(Collectors.groupingBy(product -> product.category, Collectors.summarizingInt(p -> 1)));
	}
	public Map<ProductCategory, Double> averagePriceByCategory(){
		return productMap.values().stream()
				.collect(Collectors.groupingBy(
						product -> product.category,
						Collectors.averagingDouble(p -> p.price)));
		
	}
	public List<Integer> searchProductIdsByDescription(String name){
		return productMap.values().stream()
				.filter(pro -> pro.description.toLowerCase().contains(name.toLowerCase()))
				.map(pro -> pro.id)
				.collect(Collectors.toList());
	}
	public boolean validateProduct(Predicate<Product> validationCriteria) {
		return productMap.values().stream()
				.allMatch(validationCriteria);
	}
	
	

}
