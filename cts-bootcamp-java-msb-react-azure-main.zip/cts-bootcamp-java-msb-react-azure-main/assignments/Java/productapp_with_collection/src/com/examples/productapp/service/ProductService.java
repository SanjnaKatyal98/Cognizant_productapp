package com.examples.productapp.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.examples.productapp.exception.ProductNotFoundException;
import com.examples.productapp.model.Product;
import com.examples.productapp.model.ProductCategory;

public class ProductService {
	private final Map<Integer, Product> productMap = new HashMap<>();
	private int currentId = 1;

	// Add the product
	public Product addProduct(ProductCategory category, String description, double price) {
		Product product = new Product(currentId++, category, description, price);
		productMap.put(product.id, product);
		return product;
	}

	// Update the product
	public void updateProduct(int id, String description, double price) throws ProductNotFoundException {
		Product product = productMap.get(id);
		if (product == null) {
			throw new ProductNotFoundException("Product not found");
		}
		product.description = description;
		product.price = price;
		product.updateTime = LocalDateTime.now();

	}

	// Delete the product
	public void deleteProduct(int id) {
		productMap.remove(id);
	}

	// view the product byId
	public Product viewProduct(int id) throws ProductNotFoundException {
		Product product = productMap.get(id);
		if (product == null) {
			throw new ProductNotFoundException("Product not found.");
		}
		return product;
	}

	// view the All product
	public List<Product> viewAllProducts() {
		return new ArrayList<>(productMap.values());
	}

	// Count Product above 10k price
	public int countProductsAbovePrice(double threshold) {
		int count = 0;
		for (Product product : productMap.values()) {
			if (product.price > threshold) {
				count++;
			}
		}
		return count;
	}
      // Count Product by Category
	public Map<ProductCategory, Integer> countProductsByCategory() {
		Map<ProductCategory, Integer> categoryCountMap = new HashMap<>();
		for (Product product : productMap.values()) {
			categoryCountMap.put(product.category, categoryCountMap.getOrDefault(product.category, 0) + 1);
		}
		return categoryCountMap;
	}
      // Show avg price by product category	
	public Map<ProductCategory, Double> averagePriceByCategory() {
		Map<ProductCategory, Double> categoryPriceSum = new HashMap<>();
		Map<ProductCategory, Integer> categoryProductCount = new HashMap<>();

		for (Product product : productMap.values()) {
			categoryPriceSum.put(product.category,
					categoryPriceSum.getOrDefault(product.category, 0.0) + product.price);
			categoryProductCount.put(product.category, categoryProductCount.getOrDefault(product.category, 0) + 1);
		}

		Map<ProductCategory, Double> averagePriceMap = new HashMap<>();
		for (ProductCategory category : categoryPriceSum.keySet()) {
			double averagePrice = categoryPriceSum.get(category) / categoryProductCount.get(category);
			averagePriceMap.put(category, averagePrice);
		}
		return averagePriceMap;
	}
     //List product ids whose product name contains given name
	public List<Integer> searchProductIdsByDescription(String name) {
		List<Integer> resultIds = new ArrayList<>();
		for (Product product : productMap.values()) {
			if (product.description.toLowerCase().contains(name.toLowerCase())) {
				resultIds.add(product.id);
			}
		}
		return resultIds;
	}

}
