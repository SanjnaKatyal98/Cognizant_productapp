package com.examples.productapp.model;

public enum ProductCategory {
	MOBILES , LAPTOPS, Furnitures, Stationary

}
