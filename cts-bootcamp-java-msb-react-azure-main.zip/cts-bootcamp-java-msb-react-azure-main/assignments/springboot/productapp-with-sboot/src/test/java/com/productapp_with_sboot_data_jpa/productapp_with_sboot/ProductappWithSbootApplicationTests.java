package com.productapp_with_sboot_data_jpa.productapp_with_sboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductappWithSbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
