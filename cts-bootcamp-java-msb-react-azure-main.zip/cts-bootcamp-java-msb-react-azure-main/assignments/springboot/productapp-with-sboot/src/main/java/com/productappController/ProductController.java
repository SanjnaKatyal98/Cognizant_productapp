package com.productappController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.productappDto.ProductDTO;
import com.productappEntity.Product;
import com.productappService.ProductService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/products")
@Validated
public class ProductController {
	@Autowired
	private ProductService productService;

	@GetMapping
	public List<Product> getAllProducts() {
		return productService.getAllProducts();
	}

	@GetMapping("/{id}")
	public Product getProductById(@PathVariable int id) {
		return productService.getProductById(id);
	}

	@PostMapping
	public Product createProduct(@Valid @RequestBody ProductDTO productDTO) {
		Product product = Product.builder().category(productDTO.getCategory()).description(productDTO.getDescription())
				.price(productDTO.getPrice()).active(productDTO.isActive()).createTime(productDTO.getCreateTime())
				.updateTime(productDTO.getUpdateTime()).build();
		return productService.createProduct(product);
	}

	@PutMapping("/{id}")
	public Product updateProduct(@PathVariable int id , @Valid @RequestBody ProductDTO productDTO) {

		Product updatedProduct = Product.builder().id(id)
				.category(productDTO.getCategory()).description(productDTO.getDescription())
				.price(productDTO.getPrice()).active(productDTO.isActive()).createTime(productDTO.getCreateTime())
				.updateTime(productDTO.getUpdateTime()).build();
		return productService.updateProduct(id, updatedProduct);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteProduct(@PathVariable int id) {
		productService.deleteProduct(id);
		return ResponseEntity.ok().build();
	}

}
