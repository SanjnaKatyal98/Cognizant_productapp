package com.productappService;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.productappEntity.Product;
import com.productappException.ResourceNotFoundException;
import com.productappRepository.ProductRepository;

public class ProductService {
	@Autowired
	private ProductRepository productRepository;

	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}

	public Product getProductById(int id) {
		return productRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
	}

	public Product createProduct(Product product) {
		product.setCreateTime(LocalDateTime.now());
		return productRepository.save(product);
	}

	public Product updateProduct(int id, Product newProduct) {
		return productRepository.findById(id).map(product -> {
			product.setDescription(newProduct.getDescription());
			product.setPrice(newProduct.getPrice());
			product.setActive(newProduct.isActive());
			product.setUpdateTime(LocalDateTime.now());
			return productRepository.save(product);
		}).orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
	}

	public void deleteProduct(int id) {
		if (!productRepository.existsById(id)) {
			throw new ResourceNotFoundException("Product not found with id: " + id);
		}
		productRepository.deleteById(id);
	}

}
