package com.productappEntity;

public enum ProductCategory {
    MOBILES,
    LAPTOPS,
    FURNITURES,
    STATIONARY
}
