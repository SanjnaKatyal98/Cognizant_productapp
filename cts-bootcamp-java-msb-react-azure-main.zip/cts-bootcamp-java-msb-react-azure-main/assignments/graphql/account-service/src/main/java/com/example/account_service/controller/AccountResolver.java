package com.example.account_service.controller;

import com.example.account_service.model.Account;
import com.example.account_service.service.AccountService;
import graphql.kickstart.tools.GraphQLMutationResolver;
import graphql.kickstart.tools.GraphQLQueryResolver;
import org.springframework.stereotype.Component;

import java.util.List;

@Component

public class AccountResolver implements GraphQLQueryResolver, GraphQLMutationResolver {
    private final AccountService accountService;

    public AccountResolver(AccountService accountService) {
        this.accountService = accountService;
    }

    public Account getAccount(Long id) {
        return accountService.getAccount(id).orElse(null);
    }

    public List<Account> getAccounts() {
        return accountService.getAccounts();
    }

    public Account createAccount(String name, String email) {
        Account account = new Account();
        account.setName(name);
        account.setEmail(email);
        return accountService.createAccount(account);
    }

    public Account updateAccount(Long id, String name, String email) {
        Account accountDetails = new Account();
        accountDetails.setName(name);
        accountDetails.setEmail(email);
        return accountService.updateAccount(id, accountDetails);
    }

    public String deleteAccount(Long id) {
        accountService.deleteAccount(id);
        return "Account deleted successfully";
    }

}
