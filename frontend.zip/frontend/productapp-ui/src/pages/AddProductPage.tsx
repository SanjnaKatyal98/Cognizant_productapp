import 'bootstrap/dist/css/bootstrap.min.css'
import { useForm } from "react-hook-form";
import axios from "axios";
import { useState } from "react";
import { IProduct } from "../models/IProduct";
import { useNavigate } from 'react-router-dom';

const AddProductPage = () => {
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [isError, setIsError] = useState<boolean>(false);
   const navigate = useNavigate();

  // validate the form data
  // Collect the form data
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IProduct>();

  const handleAddProduct = (formData: IProduct) => {
    console.log(formData);
    // on click of the submit button
    // send the form data to the rest api
    // what's the REST API URL? https://jsonplaceholder.typicode.com/users
    // what's the Http Method? POST
    // what's the REST API Client? Axios
    axios
      .post("http://localhost:8082/PRODUCT-SERVICE/products", formData)
      .then((response) => {
        // upon successful response
        console.log(response);
        setIsSuccess(true);
      })
      .catch((err) => {
        // upon error this will be executed)
        console.log(err);
        setIsError(true);
      })
      .finally(() => {
        setTimeout(() => {
          navigate("/HomePage");
        }, 2000);
        console.log("It is over!");
      });
  };

  return (
    <div>
      <h1>Add Product Details</h1>
      {/* <Link to="/user-manager" className="btn btn-link">
        Go Back
      </Link> */}
      <form
        className="col-md-6 offset-md-3" 
        onSubmit={handleSubmit(handleAddProduct)}
      >
        <div className="form-group row mb-3">
          <label className="col-sm-4 col-form-label" htmlFor="nameInput">
            Category
          </label>
          <div className="col-sm-12">
            <input
              type="text"
              id="categoryInput"
              className="form-control"
              placeholder="Enter Product Name"
              {...register("category", {
                required: "Product category is required",
                maxLength: 20,
              })}
            />
            {errors.category && (
              <p className="text-danger">{errors.category.message}</p>
            )}
          </div>
        </div>
        <div className="form-group row mb-3">
          <label htmlFor="textInput" className="col-sm-4 col-form-label">
           Description
          </label>
          <div className="col-sm-12">
            <input
              type="text"
              id="productDescription"
              className="form-control"
              placeholder="Enter Product Description"
              {...register("description", {
                required: "Product Description is required",
                maxLength: 50,
              })}
            />
            {errors.description && (
              <p className="text-danger">{errors.description.message}</p>
            )}
          </div>
        </div>
        <div className="form-group row mb-3">
          <label htmlFor="priceInput" className="col-sm-4 col-form-label">
            Price
          </label>
          <div className="col-sm-12">
            <input
              type="number"
              id="priceInput"
              className="form-control"
              placeholder="Enter Price of the Product"
              {...register("price", { required: "Price is required" })}
            />
            {errors.price && (
              <p className="text-danger">{errors.price.message}</p>
            )}
          </div>
        </div>

        {isSuccess && (
          <div className="alert alert-success">
            Saved Successfully. Please wait while we redirect...
          </div>
        )}

        {isError && (
          <div className="alert alert-danger">
            Some Error Occurred. Try again later!
          </div>
        )}

        <div className="form-group row">
          <div className="col-sm-12 offset-sm-2">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AddProductPage

