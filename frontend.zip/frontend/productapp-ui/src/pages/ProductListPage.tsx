import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { IProduct } from '../models/IProduct';

const ProductListPage = () => {
    const [products, setProducts] = useState<IProduct[]>([]);

useEffect(()=>{
    axios.get("http://localhost:8082/PRODUCT-SERVICE/products")
    .then((res)=>{
        console.log(res)
        console.log(res.data)
        setProducts(res.data);
    })
    .catch((err)=>{
        console.log(err);
    })
    .finally(()=>{
        console.log("API call completed");
    })
},[]);

  return (
    <>
    <h1>Show List of Products</h1>
    <div className="row">
        {products.map((product)=>{
            return(
                <div className="col-md-4" key={product.id}>
                <div className="card">
                  <img
                    src={product.image}
                    className="card-img-top"
                    width={100}
                    height={200}
                  />
                  <div className="card-body">
                    <h5 className="card-title">{product.category} </h5>
                    <h6 className="card-title">{product.description} </h6>
                    <h4>USD. {product.price}</h4>
                  </div>
                  <div className="card-footer">
                    <button
                      type="button"
                      className="btn btn-primary btn-sm"
                    >
                      Add to Cart
                    </button>
                    <button
                      type="button"
                      className="ms-2 btn btn-outline-danger btn-sm"
                    >
                      Favorite
                    </button>
                  </div>
                </div>
              </div>
            );
        })}
    </div>
    </>
  )
}
export default ProductListPage
