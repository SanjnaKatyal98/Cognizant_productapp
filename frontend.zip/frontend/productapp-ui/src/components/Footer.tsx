
const Footer = () => {
    const copyrightYear = 2024;
  const devName = "Shubhangi";

  return (
    <div className="text-align: center">
      <hr />
       <p>Copyright{copyrightYear}|@{devName}</p>
    </div>
  )
}

export default Footer
