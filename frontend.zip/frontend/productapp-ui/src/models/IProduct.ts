export interface IProduct {
  id: number;
  category: string;
  description: string;
  price: number;
  active : boolean;
  image: string;
}
