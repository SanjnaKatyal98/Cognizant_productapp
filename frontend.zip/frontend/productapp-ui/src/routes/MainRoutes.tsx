import React from 'react'
import { Route, Routes } from 'react-router-dom'
import HomePage from '../pages/HomePage'
import ProductListPage from '../pages/ProductListPage'
import AddProductPage from '../pages/AddProductPage'

const MainRoutes = () => {
  return (
    <Routes>
        <Route path='/' element={<HomePage/>}/>
        <Route path='/productlistpage' element={<ProductListPage/>}/>
        <Route path='/addProductpage' element={<AddProductPage/>}/>
    </Routes>
  )
}

export default MainRoutes
