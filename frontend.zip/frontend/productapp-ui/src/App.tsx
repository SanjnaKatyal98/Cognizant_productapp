import { BrowserRouter } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min.js'
import './App.css'
import Header from './components/Header'
import Footer from './components/Footer'
import HomePage from './pages/HomePage'
import MainRoutes from './routes/MainRoutes'

function App() {

  return (
    <>
      <BrowserRouter>
      <Header/>
      <main className="container mt-5 pt-3">
          <MainRoutes />
        </main>
      <Footer/>
    </BrowserRouter>
    </>
  )
}

export default App
